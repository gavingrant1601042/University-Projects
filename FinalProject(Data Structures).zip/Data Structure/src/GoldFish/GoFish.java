package GoldFish;
import java.util.Scanner;

public class GoFish {

    public static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
    {
        GoFishGame play = new GoFishGame();
        play.lobby();
    }

}
}
