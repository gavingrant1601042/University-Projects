package constants;

public class ProcessConstants {
	public static final String student = "Student";
	public static final String bartender = "Bartender";
}
