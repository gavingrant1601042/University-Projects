package constants;

public class ThreadConstants {
	public static final String refilling = "Refilling";
	public static final String drinking = "Drinking";
	public static final String thinking = "Thinking";
	public static final String waiting = "Waiting";
	public static final String terminated = "Terminated";
}
